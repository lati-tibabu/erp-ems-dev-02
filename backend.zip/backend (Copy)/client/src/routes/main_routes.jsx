import Home from "../pages";

const mainRoutes = {
    path: '/',
    element: <Home />,
};

export default mainRoutes;