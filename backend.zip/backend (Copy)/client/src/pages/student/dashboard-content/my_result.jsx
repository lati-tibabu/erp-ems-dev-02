import React from "react";

function MyResult() {
  return <div>MyResult</div>;
}

export default MyResult;
