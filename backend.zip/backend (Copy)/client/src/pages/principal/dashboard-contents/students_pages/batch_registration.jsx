import React from "react";

function BatchRegistration() {
  return(
    <div className="flex-column gap-20 p-20px mt-20">
        <div>Insert Student Data as Excel File</div>
        <input type="file" name="" id=""/>
        <button className="back-color-blue100 color-white">Proceed</button>
    </div>
  );

}

export default BatchRegistration;

