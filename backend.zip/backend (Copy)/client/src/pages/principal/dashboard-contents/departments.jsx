import React from "react";

function Departments() {
  return <div>Departments</div>;
}

export default Departments;
