import React from "react";

function Attendance() {
  return <div>Attendance</div>;
}

export default Attendance;
