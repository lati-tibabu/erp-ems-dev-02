import React from "react";

function Clubs() {
  return <div>Clubs</div>;
}

export default Clubs;
