import React from 'react'

function Parent() {
  return (
    <div>Parent</div>
  )
}

export default Parent;