import React from 'react'

function TestSupervisor() {
  return (
    <div className='flex-col justify-center items-center'>TestSupervisor</div>
  )
}

export default TestSupervisor