import React from 'react'

function Supervisor() {
  return (
    <div>Supervisor</div>
  )
}

export default Supervisor