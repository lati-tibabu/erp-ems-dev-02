import React from 'react'

function TestPrincipal() {
  return (
    <div className='flex-col justify-center items-center'>TestPrincipal</div>
  )
}

export default TestPrincipal