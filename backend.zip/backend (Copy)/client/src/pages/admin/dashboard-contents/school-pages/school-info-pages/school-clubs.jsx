import React from 'react'

function SchoolClubs() {
  return (
    <>
      <div>SchoolClubs</div>
      <h1>Clubs</h1>
    </>
  )
}

export default SchoolClubs;