import React from 'react'

function SchoolTeachers() {
  return (
    <>
      <div>SchoolTeachers</div>
      <h1>Teachers</h1>
    </>
  )
}

export default SchoolTeachers;