import React from 'react'

function SchoolExtras() {
  return (
    <>
      <div>SchoolExtras</div>
      <h1>Extra Activities</h1>
    </>
  )
}

export default SchoolExtras