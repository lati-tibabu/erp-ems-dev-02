import React from 'react'

function SchoolEvents() {
  return (
    <>
      <div>SchoolEvents</div>
      <h1>Events</h1>
    </>
  )
}

export default SchoolEvents