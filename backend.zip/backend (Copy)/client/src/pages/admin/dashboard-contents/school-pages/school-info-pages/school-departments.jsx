import React from 'react'

function SchoolDepartments() {
  return (
    <>
      <div>SchoolDepartments</div>
      <h1>Departments</h1>
    </>
  )
}

export default SchoolDepartments