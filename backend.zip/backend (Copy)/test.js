require("dotenv").config();
console.log(process.env);
